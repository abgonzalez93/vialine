import { useAuthToken, useGetUserData } from '@hooks/index'
import { SessionUser } from '@models/index'
import { redirect } from 'next/navigation'
import { signIn } from '@auth/index'

export default async function LoginTokenPage({ params }: { params: { token: string } }) {
  const { token } = params

  if (!token) redirect('/login/error')

  try {
    const { authToken } = useAuthToken()
    const { getUserData } = useGetUserData()

    const { access_token, refresh_token, expires_in } = await authToken(token)
    const user: SessionUser = await getUserData(access_token)

    await signIn('credentials', {
      token: access_token,
      refreshToken: refresh_token,
      expiresIn: expires_in.toString(),
      user: JSON.stringify(user),
    })

    redirect('/')
  } catch (error) {
    console.error('Error al iniciar sesión con token:', error)
    redirect('/login/error')
  }
}
