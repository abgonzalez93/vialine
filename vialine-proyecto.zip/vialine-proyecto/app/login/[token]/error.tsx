export default function LoginErrorPage() {
  return (
    <div className="flex justify-center items-center h-screen bg-red-50 text-red-700">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-2">Acceso denegado</h2>
        <p>El enlace de acceso no es válido o ha expirado.</p>
      </div>
    </div>
  )
}
