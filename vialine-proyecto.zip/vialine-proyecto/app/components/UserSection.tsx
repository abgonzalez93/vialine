import { auth } from '@auth/index'
import Image from 'next/image'

export const UserSection = async () => {
  const session = await auth()
  console.log('SESSION:', session)
  const user = session?.user

  if (!user) return null

  return (
    <div className="flex items-center gap-3">
      {user.image ? (
        <Image
          src={user.image}
          alt="Avatar"
          width={32}
          height={32}
          className="rounded-full"
        />
      ) : (
        <div className="w-8 h-8 bg-gray-300 rounded-full" />
      )}
      <span className="text-sm text-gray-700">{user.name}</span>
    </div>
  )
}
