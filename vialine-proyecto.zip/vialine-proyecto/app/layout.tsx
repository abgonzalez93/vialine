import { LANGUAGE_CONFIG } from '@constants/index'
import { METADATA_CONFIG } from '@metadata/index'
import { Providers } from '@providers/providers'
import { UserSection } from '@components/index'
import { ReactNode } from 'react'
import '@styles/globals.css'

export const metadata = METADATA_CONFIG

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang={LANGUAGE_CONFIG.DEFAULT_LANGUAGE}>
      <body>
        <Providers>
          <div className="flex min-h-screen">
            {/* Sidebar */}
            <aside className="w-64 bg-gray-800 text-white p-4">
              <h2 className="text-xl font-bold mb-4">Sidebar</h2>
            </aside>

            {/* Main content */}
            <div className="flex-1 flex flex-col">
              <header className="bg-white shadow p-4">
                <h1 className="text-2xl font-semibold">Encabezado</h1>
                <UserSection />
              </header>
              <main className="flex-1 p-6 bg-gray-50">{children}</main>
              <footer className="bg-white shadow p-4 text-center text-sm text-gray-500">© 2025 Vialine. Todos los derechos reservados.</footer>
            </div>
          </div>
        </Providers>
      </body>
    </html>
  )
}
