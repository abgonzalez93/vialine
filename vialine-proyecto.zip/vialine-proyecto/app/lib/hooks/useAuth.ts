'use client'

import { useRefreshToken } from '@hooks/index'
import { useSession } from 'next-auth/react'
import { useEffect } from 'react'

/**
 * Hook que expone los datos de sesión actual del usuario autenticado.
 * También gestiona la renovación automática del token de acceso.
 */
export const useAuth = () => {
  const { data: session, status } = useSession()

  const accessToken = session?.accessToken ?? ''
  const refreshTokenValue = session?.refreshToken ?? ''
  const expiresAt = session?.expiresAt ?? ''
  const user = session?.user

  const { refreshToken } = useRefreshToken()

  useEffect(() => {
    if (!accessToken || !refreshTokenValue || !expiresAt || !user) return

    const now = Date.now()
    const timeLeft = expiresAt - now
    const refreshIn = timeLeft - 60000 // 1 minuto antes de expirar

    if (refreshIn <= 0) {
      refreshToken(accessToken, refreshTokenValue)
      return
    }

    const timeout = setTimeout(() => {
      refreshToken(accessToken, refreshTokenValue)
    }, refreshIn)

    return () => clearTimeout(timeout)
  }, [accessToken, refreshTokenValue, expiresAt, user, refreshToken])

  return {
    user,
    accessToken,
    refreshToken: refreshTokenValue,
    expiresAt,
    isLoading: status === 'loading',
    isLoggedIn: !!user,
  }
}
