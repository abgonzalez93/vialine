import { BackendUser, SessionUser } from '@models/index'
import { parseBackendUser } from '@utils/index'

/**
 * Hook para obtener los datos del usuario autenticado desde el backend.
 * Devuelve un SessionUser listo para almacenar en la sesión.
 */
export const useGetUserData = () => {
  const getUserData = async (accessToken: string): Promise<SessionUser> => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/user`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (!response.ok) throw new Error('Error obteniendo datos del usuario')

    const apiUser: BackendUser = await response.json()

    // Adaptamos al modelo de sesión
    return parseBackendUser(apiUser, accessToken)
  }

  return { getUserData }
}
