import { AuthTokenResponse } from '@models/index'

/**
 * Hook para autenticar un token temporal con el backend.
 * Devuelve los tokens necesarios para iniciar sesión (access, refresh, etc).
 */
export const useAuthToken = () => {
  const authToken = async (token: string): Promise<AuthTokenResponse> => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-token-autologin': token,
      },
    })

    if (!response.ok) throw new Error('Error autenticando token')

    const data: AuthTokenResponse = await response.json()
    return data
  }

  return { authToken }
}
