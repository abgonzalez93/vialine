import { SessionUser } from '@models/index'
import { signIn } from '@auth/index'

/**
 * Hook que permite iniciar sesión manualmente con NextAuth
 * usando el proveedor de credenciales personalizado (`credentials`).
 *
 * Se utiliza en el login automático con token o tras el refresh del token.
 */
export const useAuthLogin = () => {
  const authLogin = async (
    token: string,
    refreshToken: string,
    expiresIn: number,
    user?: Partial<SessionUser>
  ): Promise<void> => {
    await signIn('credentials', {
      token,
      refreshToken,
      expiresIn,
      user: JSON.stringify(user),
      redirect: false,
    })
  }

  return { authLogin }
}
