import { AuthTokenResponse, SessionUser } from '@models/index'
import { useAuthLogin } from '@hooks/index'

/**
 * Hook que permite renovar el access token usando el refresh token.
 * Luego de renovar, actualiza la sesión del usuario con los nuevos tokens.
 */
export const useRefreshToken = () => {
  const { authLogin } = useAuthLogin()

  const refreshToken = async (
    accessToken: string,
    refreshTokenValue: string,
    user?: Partial<SessionUser>
  ): Promise<AuthTokenResponse> => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ refresh_token: refreshTokenValue }),
    })

    if (!response.ok) throw new Error('No se pudo renovar el token')

    const data: AuthTokenResponse = await response.json()

    await authLogin(data.access_token, data.refresh_token, data.expires_in, user)

    return data
  }

  return { refreshToken }
}
