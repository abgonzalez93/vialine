import { SessionUser, AuthTokenPayload } from '@models/index'
import { Session, User } from 'next-auth'
import { JWT } from 'next-auth/jwt'

export const jwtCallback = async ({
  token,
  user,
}: {
  token: JWT
  user?: User
}): Promise<JWT> => {
  if (user) {
    const sessionUser = user as SessionUser

    token.id = sessionUser.id
    token.name = sessionUser.name
    token.email = sessionUser.email
    token.image = sessionUser.image
    token.accessToken = sessionUser.access_token
    token.refreshToken = sessionUser.refresh_token
    token.expiresAt = Math.floor(Date.now() / 1000) + sessionUser.expires_in

    token.superadmin = sessionUser.superadmin
    token.vialine = sessionUser.vialine
    token.activo = sessionUser.activo
    token.rol_id = sessionUser.rol_id
    token.ayuntamiento_id = sessionUser.ayuntamiento_id
  }

  return token
}

export const sessionCallback = async ({
  session,
  token,
}: {
  session: Session
  token: JWT
}): Promise<Session> => {
  console.log('[sessionCallback] token:', token)

  const typedToken = token as AuthTokenPayload

  session.user = {
    id: typedToken.id ?? '',
    email: typedToken.email ?? '',
    name: typedToken.name ?? '',
    image: typedToken.image ?? undefined,

    access_token: typedToken.accessToken ?? '',
    refresh_token: typedToken.refreshToken ?? '',
    expires_in: 0,

    superadmin: typedToken.superadmin ?? false,
    vialine: typedToken.vialine ?? false,
    activo: typedToken.activo ?? false,
    rol_id: typedToken.rol_id ?? 0,
    ayuntamiento_id: typedToken.ayuntamiento_id ?? null,
  }

  session.accessToken = typedToken.accessToken ?? ''
  session.refreshToken = typedToken.refreshToken ?? ''
  session.expiresAt = typedToken.expiresAt ?? 0

  return session
}
