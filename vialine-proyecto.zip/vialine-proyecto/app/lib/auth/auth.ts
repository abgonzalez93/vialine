import { jwtCallback, sessionCallback } from '@auth/index'
import Credentials from 'next-auth/providers/credentials'
import { SessionUser } from '@models/index'
import NextAuth from 'next-auth'

/**
 * Configuración de NextAuth para autenticación personalizada por token.
 * Se utiliza `credentials` provider con tokens obtenidos desde el backend.
 */
export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      name: 'Vialine login',
      credentials: {
        token: { label: 'Token', type: 'text' },
        refreshToken: { label: 'Refresh Token', type: 'text' },
        expiresIn: { label: 'Expires In', type: 'text' },
        user: { label: 'User JSON', type: 'text' },
      },
      async authorize(credentials): Promise<SessionUser | null> {
        console.log('[authorize] Se está ejecutando')
        const token = credentials?.token as string
        const refreshToken = credentials?.refreshToken as string
        const expiresIn = parseInt(credentials?.expiresIn as string ?? '0')
        const userJSON = credentials?.user as string

        if (!token || !userJSON || !refreshToken || !expiresIn) {
          console.warn("Credenciales incompletas:", { token, refreshToken, expiresIn, userJSON })
          return null
        }

        try {
          const parsedUser: SessionUser = JSON.parse(userJSON)

          /* return {
            ...parsedUser,
            access_token: token,
            refresh_token: refreshToken,
            expires_in: expiresIn,
          } */

            return {
              id: '123',
              name: 'Juan Pérez',
              email: 'juan@example.com',
              image: 'https://i.pravatar.cc/150?u=juan@example.com',
              access_token: 'mock-token',
              refresh_token: 'mock-refresh',
              expires_in: 3600,
              rol_id: 1,
              superadmin: true,
              activo: true,
              ayuntamiento_id: 10,
              vialine: false,
            }
        } catch (error) {
          console.error('Error al parsear usuario:', error instanceof Error ? error.message : error)
          return null
        }
      }
    }),
  ],
  session: {
    strategy: 'jwt',
  },
  callbacks: {
    jwt: jwtCallback,
    session: sessionCallback,
  }
})
