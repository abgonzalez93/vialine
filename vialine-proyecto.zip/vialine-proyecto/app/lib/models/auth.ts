import { JWT } from 'next-auth/jwt'

/**
 * Representa al usuario tal como se recibe desde el backend.
 * Este modelo contiene propiedades crudas del sistema, como IDs y flags.
 */
export interface BackendUser {
  usuario_id: number
  ayuntamiento_id: number | null
  username: string
  superadmin: boolean
  vialine: boolean
  activo: boolean
  rol_id: number
}

/**
 * Representa al usuario ya adaptado al frontend y sesión.
 * Este modelo es el que se guarda en la sesión con next-auth.
 */
export interface SessionUser {
  id: string
  name: string
  email: string
  image?: string
  access_token: string
  refresh_token: string
  expires_in: number

  // Extras heredados del backend
  ayuntamiento_id?: number | null
  superadmin: boolean
  vialine: boolean
  activo: boolean
  rol_id: number
}

/**
 * Respuesta esperada del endpoint de autenticación del backend.
 */
export interface AuthTokenResponse {
  access_token: string
  token_type: 'bearer'
  expires_in: number
  refresh_token: string
}

/**
 * Payload del token JWT personalizado usado por next-auth.
 * Se usa internamente en callbacks `jwt` y `session`.
 */
export interface AuthTokenPayload extends JWT {
  id?: string
  name?: string
  email?: string
  image?: string
  accessToken?: string
  refreshToken?: string
  expiresAt?: number

  superadmin?: boolean
  vialine?: boolean
  activo?: boolean
  rol_id?: number
  ayuntamiento_id?: number | null
}
