export const APP_CONFIG = {
  NAME: 'Vialine',
  TITLE: 'Vialine | Soluciones a medida para la administración pública',
  DESCRIPTION: 'Desarrollamos servicios de apoyo administrativo para la gestión de sanciones, proyectos de seguridad vial y para la ciudadanía, con factores humanos y tecnológicos que los hacen únicos.',
}

export const LANGUAGE_CONFIG = {
  DEFAULT_LANGUAGE: 'es',
}
