import { APP_CONFIG } from '@constants/index'
import type { Metadata } from 'next'

export const METADATA_CONFIG: Metadata = {
  title: APP_CONFIG.TITLE,
  description: APP_CONFIG.DESCRIPTION,
}
