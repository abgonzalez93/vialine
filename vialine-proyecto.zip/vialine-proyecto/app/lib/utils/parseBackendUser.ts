import { BackendUser, SessionUser } from '@models/index'

export const parseBackendUser = (
  backendUser: BackendUser,
  access_token: string
): SessionUser => {
  return {
    id: String(backendUser.usuario_id),
    name: backendUser.username,
    email: '',
    image: '',

    access_token,
    refresh_token: '',
    expires_in: 3600,

    superadmin: backendUser.superadmin,
    vialine: backendUser.vialine,
    activo: backendUser.activo,
    rol_id: backendUser.rol_id,
    ayuntamiento_id: backendUser.ayuntamiento_id,
  }
}
