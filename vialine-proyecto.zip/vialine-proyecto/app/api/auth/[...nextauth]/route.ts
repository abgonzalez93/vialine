import { handlers } from "@auth/index"
export const { GET, POST } = handlers
