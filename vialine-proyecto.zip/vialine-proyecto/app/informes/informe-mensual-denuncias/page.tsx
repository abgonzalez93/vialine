export default function InformeMensualDenuncias() {
  return (
    <div>
      <h1>Informe Mensual de Denuncias</h1>
      <p>Esta es la página de informe mensual de denuncias.</p>
      {/* Aquí puedes agregar más contenido o componentes según sea necesario */}
    </div>
  )
}
