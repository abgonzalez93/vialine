export default function InformeFasesProcedimiento() {
  return (
    <div>
      <h1>Informe Fases Procedimiento</h1>
      <p>Esta es la página de informe de fases del procedimiento.</p>
      {/* Aquí puedes agregar más contenido o componentes según sea necesario */}
    </div>
  )
}
