export default function Informes() {
  return (
    <div>
      <h1>Informes</h1>
      <p>Esta es la página de informes.</p>
      {/* Aquí puedes agregar más contenido o componentes según sea necesario */}
    </div>
  )
}
