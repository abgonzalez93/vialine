export default function Home() {
  return (
    <div>
      <h1>Bienvenido a la página principal</h1>
    </div>
  )
}
