// next-auth.d.ts
import 'next-auth'
import { SessionUser } from '@models/index'

declare module 'next-auth' {
  interface Session {
    accessToken?: string
    refreshToken?: string
    expiresAt?: number
    user: SessionUser
  }
}
